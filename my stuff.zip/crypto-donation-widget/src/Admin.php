<?php
namespace KYS\CryptoDonation;

class Admin {
    public static function assets() {
        return [
            'BTC'  => ['networks' => ['bitcoin_mainnet']],
            'ETH'  => ['networks' => ['ethereum_mainnet', 'polygon_mainnet', 'bsc_mainnet']],
            'USDC' => ['networks' => ['ethereum_mainnet', 'polygon_mainnet', 'bsc_mainnet']],
            'USDT' => ['networks' => ['ethereum_mainnet', 'polygon_mainnet', 'bsc_mainnet']],
            'LTC'  => ['networks' => ['litecoin_mainnet']],
        ];
    }
    public static function avg_block_times() {
        return [
            'bitcoin_mainnet'  => 600,
            'ethereum_mainnet' => 12,
            'polygon_mainnet'  => 2,
            'bsc_mainnet'      => 3,
            'litecoin_mainnet' => 150,
        ];
    }
    public static function default_settings() {
        return [
            'rpc_endpoints' => [
                'ethereum_mainnet' => '',
                'polygon_mainnet'  => '',
                'bsc_mainnet'      => '',
                'bitcoin_mainnet'  => '',
                'litecoin_mainnet' => '',
            ],
            'api_keys' => [
                'infura_project_id' => '',
                'alchemy_api_key'   => '',
            ],
            'client_wallets' => [
                'BTC'  => '',
                'ETH'  => '',
                'USDC' => '',
                'USDT' => '',
                'LTC'  => '',
            ],
            'email' => [
                'to'      => get_option('admin_email'),
                'subject' => 'New Crypto Donation Received',
                'template' => "A donation has been received.\nAsset: {{asset}}\nNetwork: {{network}}\nAmount: {{amount}}\nTransaction: {{tx_hash}}\nEstimated confirmation time: {{eta}}\nAddress: {{address}}",
            ],
            'security' => [
                'key_encryption_secret' => wp_generate_password(64, true, true),
            ],
            'erc20_contracts' => [
                'ethereum_mainnet' => [
                    'USDC' => '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
                    'USDT' => '0xdAC17F958D2ee523a2206206994597C13D831ec7'
                ],
                'polygon_mainnet' => [
                    'USDC' => '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
                    'USDT' => '0xC2132D05D31c914a87C6611C10748AaCbE0F0cA'
                ],
                'bsc_mainnet' => [
                    'USDC' => '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d',
                    'USDT' => '0x55d398326f99059ff775485246999027b3197955'
                ],
            ],
            'erc20_decimals' => [
                'USDC' => 6, 'USDT' => 6
            ]
        ];
    }

    public static function sanitize_settings($input) {
        $out = get_option(Plugin::OPTION_NAME, self::default_settings());
        foreach (['ethereum_mainnet','polygon_mainnet','bsc_mainnet','bitcoin_mainnet','litecoin_mainnet'] as $net) {
            $out['rpc_endpoints'][$net] = isset($input['rpc_endpoints'][$net]) ? esc_url_raw($input['rpc_endpoints'][$net]) : ($out['rpc_endpoints'][$net] ?? '');
        }
        foreach (['infura_project_id','alchemy_api_key'] as $k) {
            $out['api_keys'][$k] = isset($input['api_keys'][$k]) ? sanitize_text_field($input['api_keys'][$k]) : ($out['api_keys'][$k] ?? '');
        }
        foreach (['BTC','ETH','USDC','USDT','LTC'] as $asset) {
            $out['client_wallets'][$asset] = isset($input['client_wallets'][$asset]) ? sanitize_text_field($input['client_wallets'][$asset]) : ($out['client_wallets'][$asset] ?? '');
        }
        $out['email']['to'] = isset($input['email']['to']) ? sanitize_email($input['email']['to']) : ($out['email']['to'] ?? get_option('admin_email'));
        $out['email']['subject'] = isset($input['email']['subject']) ? sanitize_text_field($input['email']['subject']) : ($out['email']['subject'] ?? 'New Crypto Donation Received');
        $out['email']['template'] = isset($input['email']['template']) ? wp_kses_post($input['email']['template']) : ($out['email']['template'] ?? '');
        if (!empty($input['security']['key_encryption_secret'])) {
            $out['security']['key_encryption_secret'] = sanitize_text_field($input['security']['key_encryption_secret']);
        }
        if (isset($input['erc20_contracts']) && is_array($input['erc20_contracts'])) {
            foreach ($input['erc20_contracts'] as $net => $map) {
                foreach ($map as $sym => $addr) {
                    $out['erc20_contracts'][$net][$sym] = sanitize_text_field($addr);
                }
            }
        }
        if (isset($input['erc20_decimals'])) {
            foreach ($input['erc20_decimals'] as $sym => $dec) {
                $out['erc20_decimals'][$sym] = intval($dec);
            }
        }
        return $out;
    }

    public static function render_admin_page() {
        $opt = get_option(Plugin::OPTION_NAME, self::default_settings());
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $logs = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 200");
        ?>
        <div class="wrap">
            <h1>Crypto Donation Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields(Plugin::OPTION_GROUP); ?>
                <h2>RPC endpoints</h2>
                <table class="form-table">
                    <?php foreach (['ethereum_mainnet','polygon_mainnet','bsc_mainnet','bitcoin_mainnet','litecoin_mainnet'] as $net): ?>
                    <tr><th><?php echo esc_html($net); ?></th>
                        <td><input type="url" name="<?php echo Plugin::OPTION_NAME; ?>[rpc_endpoints][<?php echo esc_attr($net); ?>]" value="<?php echo esc_attr($opt['rpc_endpoints'][$net] ?? ''); ?>" class="regular-text"></td></tr>
                    <?php endforeach; ?>
                </table>

                <h2>Client wallets</h2>
                <table class="form-table">
                    <?php foreach (['BTC','ETH','USDC','USDT','LTC'] as $a): ?>
                    <tr><th><?php echo esc_html($a); ?></th>
                        <td><input type="text" name="<?php echo Plugin::OPTION_NAME; ?>[client_wallets][<?php echo esc_attr($a); ?>]" value="<?php echo esc_attr($opt['client_wallets'][$a] ?? ''); ?>" class="regular-text"></td></tr>
                    <?php endforeach; ?>
                </table>

                <h2>ERC-20 contracts & decimals</h2>
                <table class="form-table">
                    <?php foreach (['ethereum_mainnet','polygon_mainnet','bsc_mainnet'] as $net): ?>
                    <tr><th><?php echo esc_html($net); ?> USDC</th>
                        <td><input type="text" name="<?php echo Plugin::OPTION_NAME; ?>[erc20_contracts][<?php echo esc_attr($net); ?>][USDC]" value="<?php echo esc_attr($opt['erc20_contracts'][$net]['USDC'] ?? ''); ?>" class="regular-text"></td></tr>
                    <tr><th><?php echo esc_html($net); ?> USDT</th>
                        <td><input type="text" name="<?php echo Plugin::OPTION_NAME; ?>[erc20_contracts][<?php echo esc_attr($net); ?>][USDT]" value="<?php echo esc_attr($opt['erc20_contracts'][$net]['USDT'] ?? ''); ?>" class="regular-text"></td></tr>
                    <?php endforeach; ?>
                    <?php foreach (['USDC','USDT'] as $sym): ?>
                    <tr><th><?php echo esc_html($sym); ?> decimals</th>
                        <td><input type="number" min="0" max="18" name="<?php echo Plugin::OPTION_NAME; ?>[erc20_decimals][<?php echo esc_attr($sym); ?>]" value="<?php echo esc_attr($opt['erc20_decimals'][$sym] ?? 6); ?>" class="small-text"></td></tr>
                    <?php endforeach; ?>
                </table>

                <h2>Email notifications</h2>
                <table class="form-table">
                    <tr><th>Send to</th><td><input type="email" name="<?php echo Plugin::OPTION_NAME; ?>[email][to]" value="<?php echo esc_attr($opt['email']['to'] ?? get_option('admin_email')); ?>" class="regular-text"></td></tr>
                    <tr><th>Subject</th><td><input type="text" name="<?php echo Plugin::OPTION_NAME; ?>[email][subject]" value="<?php echo esc_attr($opt['email']['subject'] ?? ''); ?>" class="regular-text"></td></tr>
                    <tr><th>Template</th><td><textarea name="<?php echo Plugin::OPTION_NAME; ?>[email][template]" rows="8" class="large-text"><?php echo esc_textarea($opt['email']['template'] ?? ''); ?></textarea></td></tr>
                </table>

                <h2>Security</h2>
                <table class="form-table">
                    <tr><th>Key encryption secret</th><td><input type="text" name="<?php echo Plugin::OPTION_NAME; ?>[security][key_encryption_secret]" value="<?php echo esc_attr($opt['security']['key_encryption_secret'] ?? ''); ?>" class="regular-text"></td></tr>
                </table>

                <?php submit_button(); ?>
            </form>

            <h2>Transactions</h2>
            <table class="widefat fixed striped">
                <thead><tr>
                    <th>ID</th><th>Asset</th><th>Network</th><th>Amount</th><th>Address</th><th>Status</th><th>Confs</th><th>Tx Hash</th><th>Error</th><th>Actions</th>
                </tr></thead>
                <tbody>
                <?php if ($logs): foreach ($logs as $r): ?>
                    <tr>
                        <td><?php echo (int)$r->id; ?></td>
                        <td><?php echo esc_html($r->asset); ?></td>
                        <td><?php echo esc_html($r->network); ?></td>
                        <td><?php echo esc_html($r->amount); ?></td>
                        <td><?php echo esc_html($r->address); ?></td>
                        <td><?php echo esc_html($r->status); ?></td>
                        <td><?php echo (int)$r->confirmations; ?></td>
                        <td><?php echo esc_html($r->tx_hash); ?></td>
                        <td><?php echo esc_html($r->error); ?></td>
                        <td>
                            <button class="button button-secondary kys-resend-email" data-id="<?php echo (int)$r->id; ?>">Resend email</button>
                            <button class="button button-secondary kys-manual-sweep" data-id="<?php echo (int)$r->id; ?>">Manual sweep</button>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="10">No transactions yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function render_widget_html() {
        ob_start(); ?>
        <div class="kys-crypto-widget">
            <div class="kys-steps">
                <div class="kys-step" data-step="1">
                    <h3 class="kys-step-title">Choose cryptocurrency and network</h3>
                    <form id="kys-step-1"><?php wp_nonce_field('kys_crypto_nonce','kys_crypto_nonce_field'); ?>
                        <div class="kys-field"><label><span>Crypto</span></label>
                            <select id="kys-asset" name="asset">
                                <option value="">Select a crypto</option>
                                <?php foreach (self::assets() as $s => $d) echo '<option value="'.esc_attr($s).'">'.esc_html($s).'</option>'; ?>
                            </select></div>
                        <div class="kys-field"><label><span>Network</span></label>
                            <select id="kys-network" name="network"><option value="">Select a network</option></select></div>
                        <button type="button" class="button button-primary" id="kys-next-1">Next</button>
                    </form>
                </div>
                <div class="kys-step" data-step="2" style="display:none;">
                    <h3 class="kys-step-title">Enter donation amount</h3>
                    <form id="kys-step-2">
                        <div class="kys-field"><label><span>Amount</span></label>
                            <input type="text" id="kys-amount" name="amount" inputmode="decimal" placeholder="0.00" required></div>
                        <button type="button" class="button button-primary" id="kys-next-2">Generate address</button>
                    </form>
                </div>
                <div class="kys-step" data-step="3" style="display:none;">
                    <h3 class="kys-step-title">Send your donation</h3>
                    <div class="kys-summary"><p><strong>Asset:</strong> <span id="kys-summary-asset"></span></p>
                        <p><strong>Network:</strong> <span id="kys-summary-network"></span></p>
                        <p><strong>Amount:</strong> <span id="kys-summary-amount"></span></p></div>
                    <div class="kys-address-box"><p><strong>Unique address:</strong></p>
                        <pre id="kys-donation-address"></pre>
                        <button type="button" class="button" id="kys-copy-address">Copy address</button></div>
                    <div class="kys-eta"><p><strong>Estimated confirmation time:</strong> <span id="kys-eta"></span></p></div>
                    <div class="kys-status"><p><strong>Status:</strong> <span id="kys-status-line">Waiting for payment...</span></p>
                        <div class="kys-progress"><div class="kys-progress-bar" style="width:0%"></div></div></div>
                </div>
                <div class="kys-step" data-step="4" style="display:none;">
                    <h3 class="kys-step-title">Confirming transaction</h3>
                    <p id="kys-confirmation-count">Confirmations: 0</p>
                    <p id="kys-tx-hash">Transaction: -</p>
                </div>
                <div class="kys-step" data-step="5" style="display:none;">
                    <h3 class="kys-step-title">Deposit complete</h3>
                    <div class="notice notice-success"><p>Your donation has been received and secured. Thank you!</p></div>
                </div>
            </div>
        </div>
        <?php return ob_get_clean();
    }

    public static function ajax_resend_email() {
        check_ajax_referer('kys_crypto_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Forbidden'], 403);
        $id = intval($_POST['id'] ?? 0);
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));
        if (!$row) wp_send_json_error(['message' => 'Not found'], 404);
        Emailer::send([
            'asset' => $row->asset, 'network' => $row->network, 'amount' => $row->amount,
            'tx_hash' => $row->tx_hash ?: '-', 'eta' => $row->eta_seconds.' seconds', 'address' => $row->address
        ]);
        $wpdb->update($table, ['email_sent'=>1], ['id'=>$id], ['%d'], ['%d']);
        wp_send_json_success(['message' => 'Email resent']);
    }

    public static function ajax_manual_sweep() {
        check_ajax_referer('kys_crypto_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Forbidden'], 403);
        $id = intval($_POST['id'] ?? 0);
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));
        if (!$row) wp_send_json_error(['message' => 'Not found'], 404);
        $ok = Sweeper::sweep_funds($row);
        if ($ok) wp_send_json_success(['message' => 'Sweep initiated']);
        wp_send_json_error(['message' => 'Sweep failed'], 500);
    }
}
