<?php
namespace KYS\CryptoDonation;

class RpcClient {
    public static function post($url, $payload, $retries = 3, $timeout = 20) {
        $lastError = null;
        for ($i = 0; $i < $retries; $i++) {
            $res = wp_remote_post($url, [
                'headers' => ['Content-Type' => 'application/json'],
                'body'    => json_encode($payload),
                'timeout' => $timeout
            ]);
            if (!is_wp_error($res)) {
                $body = json_decode(wp_remote_retrieve_body($res), true);
                if (isset($body['error'])) {
                    $lastError = $body['error']['message'] ?? 'RPC error';
                    continue;
                }
                return $body['result'] ?? null;
            }
            $lastError = $res->get_error_message();
            sleep(1);
        }
        return new \WP_Error('rpc_failed', $lastError ?: 'RPC failed');
    }

    public static function evm($rpc_url, $method, $params = []) {
        return self::post($rpc_url, ['jsonrpc'=>'2.0','id'=>1,'method'=>$method,'params'=>$params]);
    }
}
