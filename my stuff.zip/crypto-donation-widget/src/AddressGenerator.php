<?php
namespace KYS\CryptoDonation;

use BitWasp\Bitcoin\Network\NetworkFactory;
use BitWasp\Bitcoin\Key\Factory\PrivateKeyFactory;
use BitWasp\Bitcoin\Crypto\Random\Random;
use EthereumUtil\Util;
use kornrunner\Keccak;

class AddressGenerator {
    public static function generate($asset, $network) {
        if ($asset === 'BTC' && $network === 'bitcoin_mainnet') {
            $random = new Random();
            $privFactory = new PrivateKeyFactory();
            $privateKey = $privFactory->generateCompressed($random);
            $publicKey = $privateKey->getPublicKey();
            return [
                'address' => $publicKey->getAddress()->getAddress(),
                'priv_hex' => bin2hex($privateKey->getBuffer()->getBinary()),
                'pub_hex' => $publicKey->getHex()
            ];
        }
        if ($asset === 'LTC' && $network === 'litecoin_mainnet') {
            $random = new Random();
            $privFactory = new PrivateKeyFactory();
            $privateKey = $privFactory->generateCompressed($random);
            $ltc = NetworkFactory::litecoin();
            $address = $privateKey->getPublicKey()->getAddress($ltc)->getAddress();
            return [
                'address' => $address,
                'priv_hex' => bin2hex($privateKey->getBuffer()->getBinary()),
                'pub_hex' => $privateKey->getPublicKey()->getHex()
            ];
        }
        // EVM
        $priv = bin2hex(random_bytes(32));
        $pub = Util::privateKeyToPublicKey($priv);
        $pubNoPrefix = ltrim($pub, '0x');
        $hash = Keccak::hash(hex2bin($pubNoPrefix), 256);
        $address = '0x' . substr($hash, -40);
        return ['address'=>$address, 'priv_hex'=>$priv, 'pub_hex'=>'0x'.$pubNoPrefix];
    }
}
