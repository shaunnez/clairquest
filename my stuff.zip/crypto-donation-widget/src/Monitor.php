<?php
namespace KYS\CryptoDonation;

class Monitor {
    public static function ajax_create() {
        check_ajax_referer('kys_crypto_nonce', 'nonce');
        $asset = sanitize_text_field($_POST['asset'] ?? '');
        $network = sanitize_text_field($_POST['network'] ?? '');
        $amount = sanitize_text_field($_POST['amount'] ?? '');

        $assets = Admin::assets();
        if (!isset($assets[$asset])) wp_send_json_error(['message'=>'Unsupported asset'], 400);
        if (!in_array($network, $assets[$asset]['networks'], true)) wp_send_json_error(['message'=>'Unsupported network'], 400);
        if (!is_numeric($amount) || (float)$amount <= 0) wp_send_json_error(['message'=>'Invalid amount'], 400);

        try {
            $gen = AddressGenerator::generate($asset, $network);
        } catch (\Throwable $e) {
            wp_send_json_error(['message'=>'Address generation failed'], 500);
        }

        $eta = Admin::avg_block_times()[$network] ?? 60;
        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $client_wallet = $settings['client_wallets'][$asset] ?? '';

        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $enc_priv = Utils::encrypt_privkey($gen['priv_hex']);
        $ok = $wpdb->insert($table, [
            'created_at' => current_time('mysql'),
            'asset' => $asset,
            'network' => $network,
            'amount' => $amount,
            'address' => $gen['address'],
            'private_key_enc' => $enc_priv,
            'public_key' => $gen['pub_hex'],
            'eta_seconds' => $eta,
            'client_wallet' => $client_wallet,
            'expected_confirmations' => 1,
            'status' => 'pending',
        ], ['%s','%s','%s','%f','%s','%s','%s','%d','%s','%d','%s']);
        if (!$ok) wp_send_json_error(['message'=>'Database insert failed'], 500);

        wp_send_json_success(['id'=>$wpdb->insert_id,'address'=>$gen['address'],'eta'=>$eta]);
    }

    public static function ajax_poll() {
        check_ajax_referer('kys_crypto_nonce', 'nonce');
        $id = intval($_POST['id'] ?? 0);
        if (!$id) wp_send_json_error(['message'=>'Invalid request'], 400);
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $id));
        if (!$row) wp_send_json_error(['message'=>'Not found'], 404);
        $update = self::check_and_update_transaction($row);
        wp_send_json_success(['status'=>$update['status'],'confirmations'=>$update['confirmations'],'tx_hash'=>$update['tx_hash'],'error'=>$update['error'] ?? null]);
    }

    public static function cron_process() {
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE status IN ('pending','received','confirmed')");
        foreach ($rows as $row) self::check_and_update_transaction($row);
    }

    public static function check_and_update_transaction($row) {
        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $rpc = $settings['rpc_endpoints'][$row->network] ?? '';
        $asset = $row->asset; $network = $row->network; $address = $row->address; $amount = (float)$row->amount;

        $status = $row->status; $tx_hash = $row->tx_hash; $confirmations = (int)$row->confirmations; $error = null;

        try {
            if ($network === 'bitcoin_mainnet') {
                $btc = Sweeper::btc_check_payment_and_confirmations($rpc, $address, $amount);
                if ($btc['received'] && $status==='pending') { $status='received'; $tx_hash=$btc['tx_hash']; }
                if ($btc['confirmations'] >= 1) { $status='confirmed'; $confirmations=$btc['confirmations']; }
                if ($status==='confirmed') { if (Sweeper::btc_sweep($rpc, $row, $btc)) $status='swept'; }
            } elseif ($network === 'litecoin_mainnet') {
                $ltc = Sweeper::ltc_check_payment_and_confirmations($rpc, $address, $amount);
                if ($ltc['received'] && $status==='pending') { $status='received'; $tx_hash=$ltc['tx_hash']; }
                if ($ltc['confirmations'] >= 1) { $status='confirmed'; $confirmations=$ltc['confirmations']; }
                if ($status==='confirmed') { if (Sweeper::ltc_sweep($rpc, $row, $ltc)) $status='swept'; }
            } else {
                $evm = Sweeper::evm_check_payment_and_confirmations($rpc, $network, $asset, $address, $amount);
                if ($evm['received'] && $status==='pending') { $status='received'; $tx_hash=$evm['tx_hash']; }
                if ($evm['confirmations'] >= 1) { $status='confirmed'; $confirmations=$evm['confirmations']; }
                if ($status==='confirmed') { if (Sweeper::evm_sweep($rpc, $network, $asset, $row, $evm)) $status='swept'; }
            }
        } catch (\Throwable $e) { $error = $e->getMessage(); }

        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $wpdb->update($table, [
            'updated_at' => current_time('mysql'),
            'status' => $status,
            'tx_hash' => $tx_hash,
            'confirmations' => $confirmations,
            'error' => $error
        ], ['id'=>$row->id], ['%s','%s','%s','%d','%s'], ['%d']);

        if ($status === 'confirmed' && !$row->email_sent) {
            Emailer::send([
                'asset'=>$asset, 'network'=>$network, 'amount'=>$amount,
                'tx_hash'=>$tx_hash ?: '-', 'eta'=>$row->eta_seconds.' seconds', 'address'=>$address
            ]);
            $wpdb->update($table, ['email_sent'=>1], ['id'=>$row->id], ['%d'], ['%d']);
        }

        return ['status'=>$status,'confirmations'=>$confirmations,'tx_hash'=>$tx_hash,'error'=>$error];
    }
}
