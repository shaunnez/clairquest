<?php
namespace KYS\CryptoDonation;

class Emailer {
    public static function send($data) {
        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $to = $settings['email']['to'] ?: get_option('admin_email');
        $subject = $settings['email']['subject'] ?: 'New Crypto Donation Received';
        $template = $settings['email']['template'];
        $body = strtr($template, [
            '{{asset}}' => sanitize_text_field($data['asset']),
            '{{network}}' => sanitize_text_field($data['network']),
            '{{amount}}' => sanitize_text_field($data['amount']),
            '{{tx_hash}}' => sanitize_text_field($data['tx_hash']),
            '{{eta}}' => sanitize_text_field($data['eta']),
            '{{address}}' => sanitize_text_field($data['address']),
        ]);
        wp_mail($to, $subject, $body, ['Content-Type: text/plain; charset=UTF-8']);
    }
}
