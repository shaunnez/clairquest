<?php
namespace KYS\CryptoDonation;

use EthereumOfflineRawTx\Signer;

class Utils {
    public static function encrypt_privkey($hex) {
        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $secret = $settings['security']['key_encryption_secret'] ?: AUTH_KEY;
        $iv = substr(hash('sha256', 'kys_crypto_iv'), 0, 16);
        return openssl_encrypt($hex, 'AES-256-CBC', $secret, 0, $iv);
    }
    public static function decrypt_privkey($cipher) {
        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $secret = $settings['security']['key_encryption_secret'] ?: AUTH_KEY;
        $iv = substr(hash('sha256', 'kys_crypto_iv'), 0, 16);
        return openssl_decrypt($cipher, 'AES-256-CBC', $secret, 0, $iv);
    }

    public static function evm_build_signed_tx($nonce, $gasPrice, $gasLimit, $to, $valueWei, $data, $privHex, $network) {
        $chainIds = ['ethereum_mainnet'=>1, 'polygon_mainnet'=>137, 'bsc_mainnet'=>56];
        $chainId = $chainIds[$network] ?? 1;
        $tx = [
            'nonce'    => self::toHex($nonce),
            'gasPrice' => self::toHex($gasPrice),
            'gasLimit' => self::toHex($gasLimit),
            'to'       => $to,
            'value'    => self::toHex($valueWei),
            'data'     => $data,
            'chainId'  => $chainId,
        ];
        return Signer::sign($tx, $privHex);
    }

    public static function toHex($int) {
        $hex = dechex((int)$int);
        return '0x' . ($hex ?: '0');
    }

    public static function mark_swept($id, $txHash) {
        global $wpdb; $table = $wpdb->prefix . 'crypto_donations';
        $wpdb->update($table, ['status'=>'swept','tx_hash'=>$txHash,'updated_at'=>current_time('mysql')], ['id'=>$id], ['%s','%s','%s'], ['%d']);
    }
}
