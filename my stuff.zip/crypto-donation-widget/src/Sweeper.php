<?php
namespace KYS\CryptoDonation;

use kornrunner\Keccak;

class Sweeper {
    public static function evm_check_payment_and_confirmations($rpc, $network, $asset, $address, $amount) {
        $result = ['received'=>false,'tx_hash'=>null,'confirmations'=>0,'value'=>0];
        if (!$rpc) return $result;

        if ($asset === 'ETH') {
            $balanceHex = RpcClient::evm($rpc, 'eth_getBalance', [$address, 'latest']);
            if ($balanceHex instanceof \WP_Error || !$balanceHex) return $result;
            $balanceWei = hexdec($balanceHex);
            $expectedWei = (int)round($amount * 1e18);
            if ($balanceWei >= $expectedWei) {
                $result['received'] = true; $result['confirmations'] = 1; $result['tx_hash'] = '(balance-detected)'; $result['value'] = $balanceWei;
            }
            return $result;
        }

        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $contracts = $settings['erc20_contracts'][$network] ?? [];
        $contract = $contracts[$asset] ?? null;
        if (!$contract) return $result;

        $latestHex = RpcClient::evm($rpc, 'eth_blockNumber', []);
        if ($latestHex instanceof \WP_Error || !$latestHex) return $result;
        $latest = hexdec($latestHex);
        $fromBlock = '0x' . dechex(max(0, $latest - 5000));
        $topicTransfer = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';

        $logs = RpcClient::evm($rpc, 'eth_getLogs', [[
            'fromBlock' => $fromBlock,
            'toBlock'   => 'latest',
            'address'   => $contract,
            'topics'    => [$topicTransfer, null, self::topic_address($address)]
        ]]);
        if ($logs instanceof \WP_Error || !$logs) return $result;

        $decimals = (int)($settings['erc20_decimals'][$asset] ?? 6);
        $expected = (int)round($amount * pow(10, $decimals));

        foreach ($logs as $log) {
            $value = hexdec($log['data']);
            if ($value >= $expected) {
                $result['received'] = true;
                $result['tx_hash'] = $log['transactionHash'];
                $logBlock = hexdec($log['blockNumber']);
                $result['confirmations'] = max(0, $latest - $logBlock + 1);
                $result['value'] = $value;
                break;
            }
        }
        return $result;
    }

    public static function evm_sweep($rpc, $network, $asset, $row, $evmInfo) {
        $clientWallet = $row->client_wallet; if (empty($clientWallet)) return false;
        $priv = Utils::decrypt_privkey($row->private_key_enc); if (!$priv) return false;

        $gasPriceHex = RpcClient::evm($rpc, 'eth_gasPrice', []); if ($gasPriceHex instanceof \WP_Error || !$gasPriceHex) return false;
        $gasPrice = hexdec($gasPriceHex);
        $nonceHex = RpcClient::evm($rpc, 'eth_getTransactionCount', [$row->address, 'latest']); if ($nonceHex instanceof \WP_Error || !$nonceHex) return false;
        $nonce = hexdec($nonceHex);

        if ($asset === 'ETH') {
            $gasLimit = 21000;
            $balanceHex = RpcClient::evm($rpc, 'eth_getBalance', [$row->address, 'latest']); if ($balanceHex instanceof \WP_Error || !$balanceHex) return false;
            $balance = hexdec($balanceHex);
            $fee = $gasPrice * $gasLimit;
            $value = max(0, $balance - $fee);
            if ($value <= 0) return false;

            $raw = Utils::evm_build_signed_tx($nonce, $gasPrice, $gasLimit, $clientWallet, $value, '0x', $priv, $network);
            $txHash = RpcClient::evm($rpc, 'eth_sendRawTransaction', [$raw]);
            if ($txHash instanceof \WP_Error || !$txHash) return false;
            Utils::mark_swept($row->id, $txHash);
            return true;
        }

        $settings = get_option(Plugin::OPTION_NAME, Admin::default_settings());
        $contracts = $settings['erc20_contracts'][$network] ?? [];
        $contract = $contracts[$asset] ?? null; if (!$contract) return false;
        $decimals = (int)($settings['erc20_decimals'][$asset] ?? 6);
        $value = (int)round($row->amount * pow(10, $decimals));

        $methodId = substr(Keccak::hash('transfer(address,uint256)', 256), 0, 8);
        $toPadded = str_pad(strtolower(str_replace('0x','',$clientWallet)), 64, '0', STR_PAD_LEFT);
        $valHex = dechex($value);
        $valPadded = str_pad($valHex, 64, '0', STR_PAD_LEFT);
        $data = '0x' . $methodId . $toPadded . $valPadded;

        $gasLimitHex = RpcClient::evm($rpc, 'eth_estimateGas', [[ 'from'=>$row->address, 'to'=>$contract, 'data'=>$data ]]);
        $gasLimit = ($gasLimitHex instanceof \WP_Error || !$gasLimitHex) ? 80000 : hexdec($gasLimitHex);

        $raw = Utils::evm_build_signed_tx($nonce, $gasPrice, $gasLimit, $contract, 0, $data, $priv, $network);
        $txHash = RpcClient::evm($rpc, 'eth_sendRawTransaction', [$raw]);
        if ($txHash instanceof \WP_Error || !$txHash) return false;
        Utils::mark_swept($row->id, $txHash);
        return true;
    }

    public static function btc_check_payment_and_confirmations($rpc, $address, $amount) {
        // Note: sweeping BTC/LTC reliably requires UTXO discovery. If your node has addressindex,
        // you can use getaddressutxos or importaddress+listunspent.
        // Here we return not received unless you integrate your node’s address tracking.
        return ['received'=>false,'tx_hash'=>null,'confirmations'=>0];
    }

    public static function btc_sweep($rpc, $row, $info) { return false; }
    public static function ltc_check_payment_and_confirmations($rpc, $address, $amount) { return ['received'=>false,'tx_hash'=>null,'confirmations'=>0]; }
    public static function ltc_sweep($rpc, $row, $info) { return false; }

    private static function topic_address($address) {
        $clean = strtolower(str_replace('0x','',$address));
        return '0x' . str_pad('', 24, '0') . $clean;
    }
}
