<?php
namespace KYS\CryptoDonation;

class Plugin {
    const VERSION = '2.0.0';
    const OPTION_GROUP = 'kys_crypto_donation_options';
    const OPTION_NAME  = 'kys_crypto_donation_settings';

    private $file;

    public function __construct($file) { $this->file = $file; }

    public function init() {
        register_activation_hook($this->file, [$this, 'on_activate']);
        add_action('init', [$this, 'register_block']);
        add_action('init', [$this, 'register_shortcode']);
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);

        // AJAX endpoints
        add_action('wp_ajax_kys_crypto_create', [Monitor::class, 'ajax_create']);
        add_action('wp_ajax_nopriv_kys_crypto_create', [Monitor::class, 'ajax_create']);
        add_action('wp_ajax_kys_crypto_poll', [Monitor::class, 'ajax_poll']);
        add_action('wp_ajax_nopriv_kys_crypto_poll', [Monitor::class, 'ajax_poll']);
        add_action('wp_ajax_kys_crypto_resend_email', [Admin::class, 'ajax_resend_email']);
        add_action('wp_ajax_kys_crypto_manual_sweep', [Admin::class, 'ajax_manual_sweep']);

        // Cron
        add_filter('cron_schedules', function($s){ $s['five_minutes']=['interval'=>300,'display'=>'Every Five Minutes']; return $s; });
        add_action('kys_crypto_cron_process', [Monitor::class, 'cron_process']);
        if (!wp_next_scheduled('kys_crypto_cron_process')) wp_schedule_event(time()+120, 'five_minutes', 'kys_crypto_cron_process');
    }

    public function on_activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'crypto_donations';
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NULL,
            asset VARCHAR(16) NOT NULL,
            network VARCHAR(32) NOT NULL,
            amount DECIMAL(32, 18) NOT NULL,
            address VARCHAR(128) NOT NULL,
            private_key_enc TEXT NOT NULL,
            public_key TEXT NULL,
            tx_hash VARCHAR(128) NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'pending',
            confirmations INT DEFAULT 0,
            expected_confirmations INT DEFAULT 1,
            eta_seconds INT DEFAULT 0,
            client_wallet VARCHAR(128) NULL,
            email_sent TINYINT(1) DEFAULT 0,
            error TEXT NULL,
            meta LONGTEXT NULL,
            PRIMARY KEY (id),
            INDEX(asset), INDEX(network), INDEX(address), INDEX(status)
        ) {$charset};";
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        // Defaults
        if (!get_option(self::OPTION_NAME)) {
            add_option(self::OPTION_NAME, Admin::default_settings());
        }
    }

    public function register_shortcode() {
        add_shortcode('crypto_donation_widget', function(){ return Admin::render_widget_html(); });
    }

    public function register_block() {
        if (function_exists('register_block_type')) {
            register_block_type('kys/crypto-donation-widget', [
                'render_callback' => function(){ return Admin::render_widget_html(); },
                'attributes' => []
            ]);
        }
    }

    public function enqueue_frontend() {
        wp_enqueue_style('kys-crypto-style', plugins_url('../assets/frontend.css', __FILE__), [], self::VERSION);
        wp_enqueue_script('kys-crypto-script', plugins_url('../assets/frontend.js', __FILE__), ['jquery'], self::VERSION, true);
        wp_localize_script('kys-crypto-script', 'kysCryptoDonation', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('kys_crypto_nonce'),
            'assets'   => Admin::assets(),
            'avgBlockTimes' => Admin::avg_block_times()
        ]);
    }

    public function enqueue_admin($hook) {
        if ($hook === 'toplevel_page_kys-crypto-donations') {
            wp_enqueue_style('kys-crypto-admin', plugins_url('../assets/admin.css', __FILE__), [], self::VERSION);
            wp_enqueue_script('kys-crypto-admin', plugins_url('../assets/admin.js', __FILE__), ['jquery'], self::VERSION, true);
            wp_localize_script('kys-crypto-admin', 'kysCryptoAdmin', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('kys_crypto_nonce')
            ]);
        }
    }

    public function register_admin_menu() {
        add_menu_page('Donations', 'Donations', 'manage_options', 'kys-crypto-donations', [Admin::class, 'render_admin_page'], 'dashicons-money-alt', 58);
    }

    public function register_settings() {
        register_setting(self::OPTION_GROUP, self::OPTION_NAME, ['sanitize_callback' => [Admin::class, 'sanitize_settings']]);
    }
}
