(function ($) {
  $(document).on("click", ".kys-resend-email", function () {
    var id = $(this).data("id");
    $.post(kysCryptoAdmin.ajax_url, {
      action: "kys_crypto_resend_email",
      nonce: kysCryptoAdmin.nonce,
      id: id,
    }).done(function (res) {
      alert(
        res.success
          ? "Email resent"
          : res.data && res.data.message
          ? res.data.message
          : "Error"
      );
    });
  });
  $(document).on("click", ".kys-manual-sweep", function () {
    var id = $(this).data("id");
    if (!confirm("Initiate manual sweep for this donation?")) return;
    $.post(kysCryptoAdmin.ajax_url, {
      action: "kys_crypto_manual_sweep",
      nonce: kysCryptoAdmin.nonce,
      id: id,
    }).done(function (res) {
      alert(
        res.success
          ? "Sweep initiated"
          : res.data && res.data.message
          ? res.data.message
          : "Sweep failed"
      );
    });
  });
})(jQuery);
