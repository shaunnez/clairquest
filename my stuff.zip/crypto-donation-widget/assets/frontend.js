(function ($) {
  var step = 1,
    donation = {
      asset: "",
      network: "",
      amount: 0,
      id: null,
      address: "",
      eta: 0,
    };
  function goto(n) {
    $(".kys-step").hide();
    $(".kys-step[data-step=" + n + "]").show();
    step = n;
  }
  function fillNetworks() {
    var asset = $("#kys-asset").val();
    var nets = (kysCryptoDonation.assets[asset] || {}).networks || [];
    var $net = $("#kys-network");
    $net.empty().append('<option value="">Select a network</option>');
    nets.forEach(function (n) {
      $net.append(
        '<option value="' + n + '">' + n.replace("_", " ") + "</option>"
      );
    });
  }
  $("#kys-asset").on("change", fillNetworks);
  $("#kys-next-1").on("click", function () {
    var asset = $("#kys-asset").val(),
      network = $("#kys-network").val();
    if (!asset || !network) {
      alert("Please select asset and network");
      return;
    }
    donation.asset = asset;
    donation.network = network;
    goto(2);
  });
  $("#kys-next-2").on("click", function () {
    var amt = $("#kys-amount").val().trim();
    if (!amt || isNaN(parseFloat(amt)) || parseFloat(amt) <= 0) {
      alert("Enter a valid amount");
      return;
    }
    donation.amount = parseFloat(amt);
    $.post(kysCryptoDonation.ajax_url, {
      action: "kys_crypto_create",
      nonce: kysCryptoDonation.nonce,
      asset: donation.asset,
      network: donation.network,
      amount: donation.amount,
    })
      .done(function (res) {
        if (!res.success) {
          alert(res.data && res.data.message ? res.data.message : "Error");
          return;
        }
        donation.id = res.data.id;
        donation.address = res.data.address;
        donation.eta = res.data.eta;
        $("#kys-summary-asset").text(donation.asset);
        $("#kys-summary-network").text(donation.network);
        $("#kys-summary-amount").text(donation.amount);
        $("#kys-donation-address").text(donation.address);
        var mins = Math.round(donation.eta / 60);
        $("#kys-eta").text(
          mins > 0 ? mins + " minutes" : donation.eta + " seconds"
        );
        goto(3);
        startPolling();
      })
      .fail(function () {
        alert("Network error");
      });
  });
  $("#kys-copy-address").on("click", function () {
    var txt = $("#kys-donation-address").text();
    navigator.clipboard.writeText(txt).then(function () {
      alert("Address copied");
    });
  });

  function startPolling() {
    var iv = setInterval(function () {
      if (!donation.id) {
        clearInterval(iv);
        return;
      }
      $.post(kysCryptoDonation.ajax_url, {
        action: "kys_crypto_poll",
        nonce: kysCryptoDonation.nonce,
        id: donation.id,
      }).done(function (res) {
        if (!res.success) {
          return;
        }
        var st = res.data.status || "pending";
        var txh = res.data.tx_hash || "-";
        var confs = res.data.confirmations || 0;
        $("#kys-status-line").text(st);
        $("#kys-confirmation-count").text("Confirmations: " + confs);
        $("#kys-tx-hash").text("Transaction: " + txh);
        var pct =
          st === "pending"
            ? 10
            : st === "received"
            ? 40
            : st === "confirmed"
            ? 80
            : st === "swept"
            ? 100
            : 20;
        $(".kys-progress-bar").css("width", pct + "%");
        if (st === "received") {
          goto(4);
        }
        if (st === "confirmed") {
          $(".kys-progress-bar").css("width", "90%");
        }
        if (st === "swept") {
          clearInterval(iv);
          $(".kys-progress-bar").css("width", "100%");
          goto(5);
        }
      });
    }, 5000);
  }
})(jQuery);
