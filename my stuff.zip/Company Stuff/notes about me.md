Cars
Dogs
Stonehnege
Moulin Rouge
Pirate costume
Snowboarding
New York
Gambling company
Family
Rarotonga - boat trip, buggies, storm, pool cocktails, coconuts, trek,
Cinque Terre - Portofino Amalfi Coast
America - highest knife crime place, yosemite, chillis
Twin powers
Croatia - split - amazing fresh water lake swim
Morzine - snowboarding almost died, daily price, the cheeessee,
Barcelona - flamenco, unground mysterious cafe cafe (esfaves), food markets, churches basicilca,
Ibiza - wild
Hannovery germanyc - tech
London
Kid - stole road signs, sports cars, bob with flash rims,
Parents

** Backwards**

Moved twice
Yoga
Gym
Nature + Walking + Surfing
Snorkelling
Raising girls
Road trips
Socailsing with friends
Brother in laws accident
Dealt with an addiction
Changed jobs
Learnt to live on my own and love myslf
Dads groups
side projects
Mindfulness, present, self development, jordan petterson, how to not give a fuck etc
Building a house from earthworks to design
Lots of mini holidays, love travelling
Foods - italin, eggs benedict, thai, medican, mid spice, vitnamese
Card games / board games
Video games
JAPAN
Rarotonga
America hoilday
Parents
UK life story

MUSIC
Ed Sheeran
Imagine Dragons
Billie Eilish / Khalid
Nothing Left Kygo
Shawn Mendes
Alan Walker
Tool
Disturbed
Deftones
Tracy Chapman
David Kushner
Polyphia -- guitar
Lidsye Stirling -- violin
Ryan Mac -- only human
Take me to church - hozier
Jeff Buckley
Radiohead
Yelawolf - rap
Fleetwood Mac
Dat punk
The rolling stones
Sam Smith
Rag n bone man - human
Rufus du sol

Alex Clare
Sia
Glass Animals
The cinematic orchestra
Eminem
Red hot chilli peppers
Incubus
Aerosmith
Led Zeppelin
Jimi Hendrix
Hooverphonic
"Shallow"
Adele

Harry Styles
Queen
Disclosure

Elton John
Tracy Chapman
Queen
Starboy the weekend
Kings tribe society
Oasis
SIA
Simon & Garfunkle
Guns and Roses
Van Halen
The Blak Keys
Eric Claptop
Cat Stevens

Jimi Hendrix
Queen
Pink Floyd

Dire Straihts
Rolling Stones
Eagles
Bon Jovi
Hooverphonic
One republic
Alex Clare

Lana Del Rey
One republic
MUSE

Kings on leon

Portishead
Massive Attack
Michael Jackson
Incubus
Nirvana
Fat Freddies
Cinematic Live

** Aisle song ** Sleeping at last
** Etta James ** first dance song

Bruno Mars
Bill Withers
Seal
Maroon 5
rank Sinatra
John Legend
Jason Mraz
Al Green
Bryan Adams
Nat King Col
